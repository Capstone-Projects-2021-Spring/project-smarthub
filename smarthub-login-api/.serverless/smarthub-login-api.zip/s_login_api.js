
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'dahlgood',
  applicationName: 'smarthub-accounts',
  appUid: 'wVtwnKtdr6HLR95vBN',
  orgUid: '5dfa4086-366f-4cf2-afe9-c7a2b7877e32',
  deploymentUid: '8644c1c5-f3e5-402e-9237-5b0f102d122b',
  serviceName: 'smarthub-login-api',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '4.5.3',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'smarthub-login-api-dev-login-api', timeout: 6 };

try {
  const userHandler = require('./handler.js');
  module.exports.handler = serverlessSDK.handler(userHandler.users, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}